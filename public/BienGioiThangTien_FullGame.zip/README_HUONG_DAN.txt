BIEN GIOI THANG TIEN - HUONG DAN CHAY GAME
Copyright 2026 by Trung tam DNQ Production
==========================================

1. Cai dat thu vien (chi can 1 lan):
   npm install

2. Chay game o che do phat trien:
   npm run dev
   Mo trinh duyet tai: http://localhost:3000

3. Dong goi ban chay production:
   npm run build
   npm run preview
